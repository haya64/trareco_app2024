from trarecoapp import app
from flask import render_template, request
from .db import conect
import random

@app.route('/')
def index():
    data_dic = {'i1': 'v1',
                'i2': 'v2'}
    return render_template('trarecoapp/index.html', my_dict=data_dic)

@app.route('/test')
def other1():
    return 'test'

@app.route('/sampleform', methods=['GET', 'POST'])
def sample_form():
    if request.method == 'GET':
        return render_template('trarecoapp/sampleform.html')
    if request.method == 'POST':
        print('POSTデータを受け取ったので処理します。')
        # req1 = request.form['data1']
        select = conect.SELECTDATA()
        req1 = select.select()
        return render_template('trarecoapp/result.html', result=req1)
    

# 画像の表示
@app.route('/image')
def show_image():
    select = conect.SELECTDATA()
    columns = 'path'
    images = select.select(columns)
    selected_image = random.choice(images) if images else None
    
    image_path = '/Users/haya/Development/university_class/mirai_pj/trareco_system/test_pictures/' + selected_image[0]
    return render_template('trarecoapp/show_image.html', image=image_path)